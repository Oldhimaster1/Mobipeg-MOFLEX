# MobiPEG Web Studio preview

Install Node.js 22 or newer. Extract this entire archive, then run `node scripts/dev-server.mjs` from its root. Open the local server on port 4173 in a modern browser. The server supplies the isolation headers required by the encoder. All video processing and storage stay in your browser.

See VALIDATION.md for tested functionality and limits. Physical 3DS long-movie playback and iPhone Safari long-duration memory behavior remain unverified.
